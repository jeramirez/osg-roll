# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/n;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$n$">|; 

$key = q/t=9+2^0=9+1=10seconds;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="257" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$t = 9 + 2^0 = 9 + 1 = 10 seconds$">|; 

$key = q/6^{th};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="$6^{th}$">|; 

$key = q/M-1;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="$M-1$">|; 

$key = q/t=9+2^{12}=9+4096=4105seconds;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="309" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="$t = 9 + 2^{12} = 9 + 4096 = 4105 seconds$">|; 

$key = q/fbox{Thissectionhasnotyetbeenwritten};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="312" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\fbox{This section has not yet been written}">|; 

$key = q/3^{rd};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$3^{rd}$">|; 

$key = q/<;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$&lt;$">|; 

$key = q/includegraphics{user-manslashsplice-complex.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="650" HEIGHT="690" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\includegraphics{user-man/splice-complex.eps}">|; 

$key = q/2^{nd};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$2^{nd}$">|; 

$key = q/(NT);MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="\(NT\)">|; 

$key = q/|;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="$\vert$">|; 

$key = q/13^{th};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$13^{th}$">|; 

$key = q/{displaymath}pi_e(u,t)=pi_r(u,t)timesf(u,t){displaymath};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="208" HEIGHT="32" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="\begin{displaymath}\pi_e(u,t) = \pi_r(u,t)\times f(u,t)\end{displaymath}">|; 

$key = q/n=0;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$n = 0$">|; 

$key = q/{}^ast;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="${}^\ast$">|; 

$key = q/t;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$t$">|; 

$key = q/t=9+2^5=9+32=41seconds;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="266" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="$t = 9 + 2^5 = 9 + 32 = 41 seconds$">|; 

$key = q/t=9+2^2=9+4=13seconds;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="257" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="$t = 9 + 2^2 = 9 + 4 = 13 seconds$">|; 

$key = q/n=2;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$n = 2$">|; 

$key = q/=;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="$=$">|; 

$key = q/includegraphics{user-manslashdagman-diamond.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="109" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics{user-man/dagman-diamond.eps}">|; 

$key = q/1^{st};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$1^{st}$">|; 

$key = q/>=;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="$&gt;=$">|; 

$key = q/fbox{Thissectionhasnotyetbeencompleted};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="335" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="\fbox{This section has not yet been completed}">|; 

$key = q/-1004;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$-1004$">|; 

$key = q/*;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="$*$">|; 

$key = q/M;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="$M$">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim2223#preform{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="315" HEIGHT="130" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="\begin{figure}\begin{verbatim}- (unary negation) (high precedence)
* /
+ -...
... &gt;= &gt;
== != =?= =!=
&amp;&amp;
\vert\vert (low precedence)\end{verbatim}
\end{figure}">|; 

$key = q/A;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="$A$">|; 

$key = q/-1;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$-1$">|; 

$key = q/{displaymath}pi_r(u,t)=betatimespi(u,t-deltat)+(1-beta)timesrho(u,t){displaymath};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="347" HEIGHT="32" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="\begin{displaymath}\pi_r(u,t) = \beta\times\pi(u,t-\delta t) + (1-\beta)\times\rho(u,t)\end{displaymath}">|; 

$key = q/fbox{Thisdefinitionisnotcomplete.};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="263" HEIGHT="46" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="\fbox{This definition is not complete.}">|; 

$key = q/{figure}{footnotesize{preform{<verbatim_mark>verbatim2220#preform{{normalsize{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="500" HEIGHT="147" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="\begin{figure}\footnotesize
\begin{verbatim}MyType = ''Machine''
TargetType = ...
...\vert LoadAvg&lt;=0.3 &amp;&amp; KeyboardIdle&gt;15*60\end{verbatim}
\normalsize\end{figure}">|; 

$key = q/includegraphics{user-manslashsplice-X.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="288" HEIGHT="262" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\includegraphics{user-man/splice-X.eps}">|; 

$key = q/beta=0.5^{{deltat}slashh};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="92" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$\beta=0.5^{{\delta t}/h}$">|; 

$key = q/includegraphics{user-manslashsplice-simple.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="260" HEIGHT="356" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\includegraphics{user-man/splice-simple.eps}">|; 

$key = q/h;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$h$">|; 

$key = q/pi_e(u,t);MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$\pi_e(u,t)$">|; 

$key = q/n=12;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="58" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="$n = 12$">|; 

$key = q/10^{12};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$10^{12}$">|; 

$key = q/t=9+2.0^0;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$t = 9
+ 2.0^0$">|; 

$key = q/n=1;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$n = 1$">|; 

$key = q/t=9+2^8=9+256=265seconds;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="284" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="$t = 9 + 2^8 = 9 + 256 = 265 seconds$">|; 

$key = q/>;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$&gt;$">|; 

$key = q/includegraphics{user-manslashdagman-node.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="411" HEIGHT="412" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics{user-man/dagman-node.eps}">|; 

$key = q/t=9+2^1=9+2=11seconds;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="257" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$t = 9 + 2^1 = 9 + 2 = 11 seconds$">|; 

$key = q/u;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="$u$">|; 

$key = q/k;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$k$">|; 

$key = q/9^{th};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="$9^{th}$">|; 

$key = q/includegraphics{user-manslashsplice-s1.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="313" HEIGHT="782" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\includegraphics{user-man/splice-s1.eps}">|; 

$key = q/includegraphics{admin-manslashstates.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="788" HEIGHT="402" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="\includegraphics{admin-man/states.eps}">|; 

$key = q/n=5;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="$n = 5$">|; 

$key = q/{displaymath}t=c+k^n{displaymath};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="79" HEIGHT="29" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\begin{displaymath}t = c + k^n\end{displaymath}">|; 

$key = q/f(u,t);MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$f(u,t)$">|; 

$key = q/c;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$c$">|; 

$key = q/includegraphics{contribslashview-screenshot.ps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="637" HEIGHT="587" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="\includegraphics{contrib/view-screenshot.ps}">|; 

$key = q/pi_r(u,t);MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$\pi_r(u,t)$">|; 

$key = q/rho(u,t);MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$\rho(u,t)$">|; 

$key = q/C;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="$C$">|; 

$key = q/includegraphics{admin-manslashactivities.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="786" HEIGHT="714" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="\includegraphics{admin-man/activities.eps}">|; 

$key = q/n=8;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$n = 8$">|; 

$key = q/B;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="$B$">|; 

$key = q/mathtt{backslash};MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$\mathtt{\backslash}$">|; 

$key = q/deltat;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="$\delta t$">|; 

$key = q/beta;MSF=1.8;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="$\beta$">|; 

1;

